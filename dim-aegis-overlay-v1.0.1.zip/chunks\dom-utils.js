function safeSetInnerHTML(element, htmlString) {
  const parser = new DOMParser();
  const parsed = parser.parseFromString(htmlString, "text/html");
  element.replaceChildren(...Array.from(parsed.body.childNodes));
}
export {
  safeSetInnerHTML as s
};
