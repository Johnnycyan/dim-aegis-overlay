const GRADE_WEIGHTS = {
  S: 4,
  A: 3,
  B: 2,
  C: 1
};
function scoreWeapon(itemHash, rolledPerks, database, enhancedToNormalMap2) {
  const defaultResult = {
    grade: null,
    matchPercentage: 0,
    matchedPerks: [],
    missingPerks: [],
    notes: "",
    wishlistPerks: []
  };
  const recommendations = database[itemHash];
  if (!recommendations || recommendations.length === 0) {
    return defaultResult;
  }
  const rolledSet = /* @__PURE__ */ new Set();
  for (const perk of rolledPerks) {
    rolledSet.add(perk);
    if (enhancedToNormalMap2 && enhancedToNormalMap2[perk]) {
      rolledSet.add(enhancedToNormalMap2[perk]);
    }
  }
  let bestResult = null;
  for (const rec of recommendations) {
    const matched = [];
    const missing = [];
    for (const perk of rec.perks) {
      if (rolledSet.has(perk)) {
        matched.push(perk);
      } else {
        missing.push(perk);
      }
    }
    const missingCount = missing.length;
    let grade = null;
    if (missingCount === 0) {
      grade = "S";
    } else if (missingCount === 1) {
      grade = "A";
    } else if (missingCount === 2) {
      grade = "B";
    } else if (missingCount === 3) {
      grade = "C";
    }
    if (grade === null) {
      continue;
    }
    const matchPercentage = Math.round(matched.length / rec.perks.length * 100);
    const result = {
      grade,
      matchPercentage,
      matchedPerks: matched,
      missingPerks: missing,
      notes: rec.notes,
      wishlistPerks: rec.perks
    };
    if (!bestResult) {
      bestResult = result;
    } else {
      const currentWeight = GRADE_WEIGHTS[result.grade];
      const bestWeight = GRADE_WEIGHTS[bestResult.grade];
      if (currentWeight > bestWeight) {
        bestResult = result;
      } else if (currentWeight === bestWeight && result.matchPercentage > bestResult.matchPercentage) {
        bestResult = result;
      }
    }
  }
  return bestResult || defaultResult;
}
let tooltipEl = null;
function getOrCreateTooltip() {
  if (!tooltipEl) {
    tooltipEl = document.createElement("div");
    tooltipEl.id = "aegis-tooltip";
    tooltipEl.className = "aegis-tooltip hidden";
    document.body.appendChild(tooltipEl);
  }
  return tooltipEl;
}
const requestedHashes = /* @__PURE__ */ new Set();
function getPerkInfo(hash, localPerksMap) {
  if (localPerksMap[hash]) {
    return localPerksMap[hash];
  }
  const registryEl = document.getElementById("aegis-global-perk-registry");
  if (registryEl) {
    const registryStr = registryEl.getAttribute("data-registry");
    if (registryStr) {
      try {
        const registry = JSON.parse(registryStr);
        if (registry[hash]) {
          return registry[hash];
        }
      } catch (e) {
      }
    }
  }
  if (registryEl && !requestedHashes.has(hash)) {
    requestedHashes.add(hash);
    const currentRequests = registryEl.getAttribute("data-request-hashes") || "";
    const requestHashes = currentRequests ? currentRequests.split(",").map((h) => h.trim()).filter(Boolean) : [];
    if (!requestHashes.includes(String(hash))) {
      requestHashes.push(String(hash));
      registryEl.setAttribute("data-request-hashes", requestHashes.join(","));
    }
  }
  return {
    name: `Perk #${hash}`,
    icon: ""
  };
}
function positionTooltip(target, tooltip) {
  const targetRect = target.getBoundingClientRect();
  tooltip.style.visibility = "hidden";
  tooltip.classList.remove("hidden");
  const tooltipRect = tooltip.getBoundingClientRect();
  tooltip.classList.add("hidden");
  tooltip.style.visibility = "";
  const tooltipWidth = tooltipRect.width || 260;
  const tooltipHeight = tooltipRect.height || 180;
  let top = targetRect.top - tooltipHeight - 8;
  let left = targetRect.left + (targetRect.width - tooltipWidth) / 2;
  if (top < 8) {
    top = targetRect.bottom + 8;
  }
  if (left < 8) {
    left = 8;
  }
  const maxLeft = window.innerWidth - tooltipWidth - 8;
  if (left > maxLeft) {
    left = maxLeft;
  }
  tooltip.style.top = `${top + window.scrollY}px`;
  tooltip.style.left = `${left + window.scrollX}px`;
}
function showTooltip(target, result, weaponName, localPerksMap, activeHashes, isLightGG) {
  const tooltip = getOrCreateTooltip();
  const isLightGGMode = !!isLightGG;
  const baseGradeLetter = result.grade ? result.grade.charAt(0).toLowerCase() : "";
  const gradeClass = `aegis-grade-${baseGradeLetter}`;
  let tagsHtml = "";
  if (result.notes) {
    const isPvE = /\bpve\b/i.test(result.notes);
    const isPvP = /\bpvp\b/i.test(result.notes);
    if (isPvE || isPvP) {
      tagsHtml = '<div class="aegis-tooltip-tags-row">';
      if (isPvE) {
        tagsHtml += '<span class="aegis-tooltip-tag aegis-tag-pve">PvE</span>';
      }
      if (isPvP) {
        tagsHtml += '<span class="aegis-tooltip-tag aegis-tag-pvp">PvP</span>';
      }
      tagsHtml += "</div>";
    }
  }
  let html = `
    <div class="aegis-tooltip-header">
      <div class="aegis-tooltip-title-row">
        <span class="aegis-tooltip-weapon-name">${weaponName}</span>
        <span class="aegis-tooltip-grade ${gradeClass}">${result.grade}</span>
      </div>
      ${tagsHtml}
  `;
  if (!isLightGGMode) {
    html += `
      <div class="aegis-tooltip-match-bar-container">
        <div class="aegis-tooltip-match-label">Match Percentage</div>
        <div class="aegis-tooltip-match-value">${result.matchPercentage}%</div>
      </div>
      <div class="aegis-tooltip-progress-bg">
        <div class="aegis-tooltip-progress-fill ${gradeClass}" style="width: ${result.matchPercentage}%"></div>
      </div>
    `;
  } else {
    html += `
      <div class="aegis-tooltip-match-bar-container">
        <div class="aegis-tooltip-match-label" style="color: #ffb300;">Light.gg Roll Appraisal</div>
      </div>
    `;
  }
  html += `
    </div>
    
    <div class="aegis-tooltip-body">
  `;
  const hasWishlist = result.wishlistPerks && result.wishlistPerks.length > 0;
  if (hasWishlist) {
    html += `
      <div class="aegis-tooltip-section">
        <div class="aegis-tooltip-section-title">Matched Perks</div>
        <div class="aegis-tooltip-perks-grid">
    `;
    if (result.matchedPerks.length === 0) {
      html += `<div class="aegis-tooltip-perk-empty">None</div>`;
    } else {
      for (const hash of result.matchedPerks) {
        const info = getPerkInfo(hash, localPerksMap);
        const iconUrl = info.icon ? `https://www.bungie.net${info.icon}` : "";
        html += `
          <div class="aegis-tooltip-perk-item aegis-matched">
            ${iconUrl ? `<img src="${iconUrl}" class="aegis-perk-icon-img" alt="" />` : '<span class="aegis-perk-bullet">•</span>'}
            <span class="aegis-perk-name-text">${info.name}</span>
          </div>
        `;
      }
    }
    html += `
        </div>
      </div>
    `;
    if (result.missingPerks.length > 0) {
      html += `
        <div class="aegis-tooltip-section">
          <div class="aegis-tooltip-section-title">Missing Perks</div>
          <div class="aegis-tooltip-perks-grid">
      `;
      for (const hash of result.missingPerks) {
        const info = getPerkInfo(hash, localPerksMap);
        const iconUrl = info.icon ? `https://www.bungie.net${info.icon}` : "";
        html += `
          <div class="aegis-tooltip-perk-item aegis-missing">
            ${iconUrl ? `<img src="${iconUrl}" class="aegis-perk-icon-img" alt="" />` : '<span class="aegis-perk-bullet">•</span>'}
            <span class="aegis-perk-name-text">${info.name}</span>
          </div>
        `;
      }
      html += `
          </div>
        </div>
      `;
    }
  } else {
    const JUNK_KEYWORDS = /tracker|empty|default|ornament|shader|catalyst|upgrade|mod socket|memento/i;
    let displayHashes = [];
    if (activeHashes && activeHashes.length > 0) {
      displayHashes = activeHashes.filter((hash) => {
        const info = localPerksMap[hash];
        if (!info)
          return false;
        return !JUNK_KEYWORDS.test(info.name);
      });
    }
    html += `
      <div class="aegis-tooltip-section">
        <div class="aegis-tooltip-section-title">Active Perks</div>
        <div class="aegis-tooltip-perks-grid">
    `;
    if (displayHashes.length === 0) {
      html += `<div class="aegis-tooltip-perk-empty">No perks detected</div>`;
    } else {
      for (const hash of displayHashes) {
        const info = localPerksMap[hash];
        const iconUrl = info.icon ? `https://www.bungie.net${info.icon}` : "";
        html += `
          <div class="aegis-tooltip-perk-item aegis-matched">
            ${iconUrl ? `<img src="${iconUrl}" class="aegis-perk-icon-img" alt="" />` : '<span class="aegis-perk-bullet">•</span>'}
            <span class="aegis-perk-name-text" style="color: #ffffff;">${info.name}</span>
          </div>
        `;
      }
    }
    html += `
        </div>
      </div>
    `;
  }
  if (result.notes) {
    html += `
      <div class="aegis-tooltip-section aegis-notes-section">
        <div class="aegis-tooltip-section-title">${isLightGGMode ? "Information" : "Aegis Notes"}</div>
        <div class="aegis-tooltip-notes-text">${result.notes}</div>
      </div>
    `;
  }
  html += `
    </div>
  `;
  tooltip.innerHTML = html;
  positionTooltip(target, tooltip);
  tooltip.classList.remove("hidden");
}
function hideTooltip() {
  if (tooltipEl) {
    tooltipEl.classList.add("hidden");
  }
}
let wishlistDb = {};
let enhancedToNormalMap = {};
let scoringSource = "aegis";
let lightggDb = {};
let hoveredElement = null;
let registryObserver = null;
function setupRegistryObserver() {
  if (registryObserver) return;
  const registryEl = document.getElementById("aegis-global-perk-registry");
  if (!registryEl) return;
  registryObserver = new MutationObserver((mutations) => {
    for (let i = 0; i < mutations.length; i++) {
      const mutation = mutations[i];
      if (mutation.type === "attributes" && mutation.attributeName === "data-registry") {
        const registryStr = registryEl.getAttribute("data-registry");
        if (registryStr) {
          try {
            chrome.storage.local.set({ perkRegistry: JSON.parse(registryStr) });
          } catch (e) {
          }
        }
        if (hoveredElement) {
          const result = hoveredElement._aegisResult;
          const name = hoveredElement._aegisName;
          const perksMap = hoveredElement._aegisPerksMap;
          const activeHashes = hoveredElement._aegisActiveHashes;
          if (result && result.grade) {
            showTooltip(hoveredElement, result, name, perksMap, activeHashes, scoringSource === "lightgg");
          }
        }
      }
    }
  });
  registryObserver.observe(registryEl, {
    attributes: true,
    attributeFilter: ["data-registry"]
  });
}
chrome.storage.local.get(["wishlistData", "enhancedToNormal", "scoringSource", "lightggData"], (res) => {
  wishlistDb = res.wishlistData || {};
  enhancedToNormalMap = res.enhancedToNormal || {};
  scoringSource = res.scoringSource || "aegis";
  lightggDb = res.lightggData || {};
  console.log(`DIM Aegis Overlay: Loaded configuration. Source: ${scoringSource}`);
  reprocessAllElements();
});
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === "local") {
    let changed = false;
    if (changes.wishlistData) {
      wishlistDb = changes.wishlistData.newValue || {};
      changed = true;
    }
    if (changes.enhancedToNormal) {
      enhancedToNormalMap = changes.enhancedToNormal.newValue || {};
      changed = true;
    }
    if (changes.scoringSource) {
      scoringSource = changes.scoringSource.newValue || "aegis";
      changed = true;
    }
    if (changes.lightggData) {
      lightggDb = changes.lightggData.newValue || {};
      changed = true;
    }
    if (changed) {
      console.log("DIM Aegis Overlay: Storage updated, re-scoring elements.");
      reprocessAllElements();
    }
  }
});
function handleMouseEnter(e) {
  const el = e.currentTarget;
  hoveredElement = el;
  setupRegistryObserver();
  const result = el._aegisResult;
  const name = el._aegisName;
  const perksMap = el._aegisPerksMap;
  const activeHashes = el._aegisActiveHashes;
  if (result && result.grade) {
    showTooltip(el, result, name, perksMap, activeHashes, scoringSource === "lightgg");
  }
}
function handleMouseLeave() {
  hoveredElement = null;
  hideTooltip();
}
function injectPopupSummary(popupContainer, result, scoringSource2) {
  const titleEl = popupContainer.querySelector('h1, [class*="title"]');
  if (!titleEl) return;
  const header = titleEl.parentElement;
  if (!header) return;
  let summaryEl = popupContainer.querySelector(".aegis-popup-summary");
  if (!result.grade) {
    if (summaryEl) summaryEl.remove();
    return;
  }
  if (!summaryEl) {
    summaryEl = document.createElement("div");
    summaryEl.className = "aegis-popup-summary";
    titleEl.insertAdjacentElement("afterend", summaryEl);
  }
  const baseGradeLetter = result.grade.charAt(0).toLowerCase();
  const gradeClass = `aegis-grade-${baseGradeLetter}`;
  const isLightGG = scoringSource2 === "lightgg";
  let notesHtml = "";
  if (result.notes) {
    notesHtml = `<div class="aegis-popup-notes-text">${result.notes}</div>`;
  }
  const matchLabel = isLightGG ? "Light.gg Roll Appraisal" : `Wishlist Match: <strong class="${gradeClass}">${result.matchPercentage}%</strong>`;
  summaryEl.innerHTML = `
    <div class="aegis-popup-summary-content">
      <div class="aegis-popup-row">
        <span class="aegis-popup-grade-badge aegis-badge-${baseGradeLetter}">${result.grade}</span>
        <span class="aegis-popup-label">${matchLabel}</span>
      </div>
      ${notesHtml}
    </div>
  `;
}
function injectBadge(el, result) {
  let badgeTarget = el.querySelector('.item-tile, [class*="StoreItem"], [class*="InventoryItem"]');
  if (badgeTarget) {
    badgeTarget.style.setProperty("position", "relative", "important");
  } else {
    badgeTarget = el;
  }
  if (badgeTarget) {
    badgeTarget.classList.remove("aegis-gold-glow");
    if (result.grade && result.grade.startsWith("S")) {
      badgeTarget.classList.add("aegis-gold-glow");
    }
  }
  let badge = badgeTarget.querySelector(".aegis-badge");
  if (!badge) {
    badge = document.createElement("div");
    badge.className = "aegis-badge";
    badgeTarget.appendChild(badge);
  }
  badge.classList.remove("aegis-badge-s", "aegis-badge-a", "aegis-badge-b", "aegis-badge-c", "aegis-badge-d", "aegis-badge-f");
  const baseLetter = result.grade ? result.grade.charAt(0).toLowerCase() : "";
  badge.classList.add(`aegis-badge-${baseLetter}`);
  badge.textContent = result.grade || "";
}
function removeBadge(el) {
  let badgeTarget = el.querySelector('.item-tile, [class*="StoreItem"], [class*="InventoryItem"]');
  if (badgeTarget) {
    badgeTarget.classList.remove("aegis-gold-glow");
  } else {
    el.classList.remove("aegis-gold-glow");
  }
  const badge = el.querySelector(".aegis-badge");
  if (badge) {
    badge.remove();
  }
}
function processElement(el) {
  var _a;
  const parentWrapper = (_a = el.parentElement) == null ? void 0 : _a.closest("[data-aegis-item-hash]");
  if (parentWrapper) {
    removeBadge(el);
    if (el.hasAttribute("data-aegis-listeners")) {
      el.removeEventListener("mouseenter", handleMouseEnter);
      el.removeEventListener("mouseleave", handleMouseLeave);
      el.removeAttribute("data-aegis-listeners");
    }
    return;
  }
  const itemHashStr = el.getAttribute("data-aegis-item-hash");
  const weaponName = el.getAttribute("data-aegis-item-name") || "Unknown Weapon";
  const perkHashesStr = el.getAttribute("data-aegis-perk-hashes");
  const perksDataStr = el.getAttribute("data-aegis-perks-data");
  if (!itemHashStr || !perkHashesStr) {
    return;
  }
  try {
    const itemHash = parseInt(itemHashStr, 10);
    const perkHashes = perkHashesStr.split(",").map((h) => parseInt(h.trim(), 10)).filter((h) => !isNaN(h));
    let perksMap = {};
    if (perksDataStr) {
      perksMap = JSON.parse(perksDataStr);
    }
    let result;
    if (scoringSource === "lightgg") {
      const rawInstanceId = el.getAttribute("data-aegis-instance-id") || el.id.replace("item-", "");
      const instanceId = rawInstanceId.replace(/^[^0-9]+/, "");
      const grade = lightggDb[instanceId];
      if (grade) {
        const aegisResult = scoreWeapon(itemHash, perkHashes, wishlistDb, enhancedToNormalMap);
        result = {
          grade,
          matchPercentage: aegisResult.grade ? aegisResult.matchPercentage : 100,
          matchedPerks: aegisResult.matchedPerks,
          missingPerks: aegisResult.missingPerks,
          notes: aegisResult.notes || "Community popularity rating from Light.gg Roll Appraiser.",
          wishlistPerks: aegisResult.wishlistPerks
        };
      } else {
        result = {
          grade: null,
          matchPercentage: 0,
          matchedPerks: [],
          missingPerks: [],
          notes: "",
          wishlistPerks: []
        };
      }
    } else {
      result = scoreWeapon(itemHash, perkHashes, wishlistDb, enhancedToNormalMap);
    }
    const activePerksDataStr = el.getAttribute("data-aegis-active-perk-hashes");
    let activeHashes = [];
    if (activePerksDataStr) {
      activeHashes = activePerksDataStr.split(",").map(Number).filter((h) => !isNaN(h) && h > 0);
    }
    el._aegisResult = result;
    el._aegisName = weaponName;
    el._aegisPerksMap = perksMap;
    el._aegisActiveHashes = activeHashes;
    if (result.grade) {
      injectBadge(el, result);
      const popupContainer = el.closest('[class*="ItemPopup"], [class*="item-popup"], [class*="Sheet"], [class*="sheet"], .item-popup');
      if (popupContainer) {
        injectPopupSummary(popupContainer, result, scoringSource);
      }
      if (!el.hasAttribute("data-aegis-listeners")) {
        el.addEventListener("mouseenter", handleMouseEnter);
        el.addEventListener("mouseleave", handleMouseLeave);
        el.setAttribute("data-aegis-listeners", "true");
      }
    } else {
      removeBadge(el);
      const popupContainer = el.closest('[class*="ItemPopup"], [class*="item-popup"], [class*="Sheet"], [class*="sheet"], .item-popup');
      if (popupContainer) {
        const summary = popupContainer.querySelector(".aegis-popup-summary");
        if (summary) summary.remove();
      }
      if (el.hasAttribute("data-aegis-listeners")) {
        el.removeEventListener("mouseenter", handleMouseEnter);
        el.removeEventListener("mouseleave", handleMouseLeave);
        el.removeAttribute("data-aegis-listeners");
      }
    }
  } catch (err) {
    console.error("Error processing element in content script:", err);
  }
}
function reprocessAllElements() {
  setupRegistryObserver();
  const elements = document.querySelectorAll("[data-aegis-item-hash]");
  for (let i = 0; i < elements.length; i++) {
    processElement(elements[i]);
  }
}
const observer = new MutationObserver((mutations) => {
  for (let i = 0; i < mutations.length; i++) {
    const mutation = mutations[i];
    if (mutation.type === "attributes" && (mutation.attributeName === "data-aegis-item-hash" || mutation.attributeName === "data-aegis-perk-hashes")) {
      processElement(mutation.target);
    }
    if (mutation.type === "childList") {
      setupRegistryObserver();
      mutation.addedNodes.forEach((node) => {
        if (node instanceof HTMLElement) {
          if (node.hasAttribute("data-aegis-item-hash")) {
            processElement(node);
          }
          const children = node.querySelectorAll("[data-aegis-item-hash]");
          children.forEach((child) => processElement(child));
        }
      });
    }
  }
});
observer.observe(document.body, {
  childList: true,
  subtree: true,
  attributes: true,
  attributeFilter: ["data-aegis-item-hash", "data-aegis-perk-hashes"]
});
reprocessAllElements();
